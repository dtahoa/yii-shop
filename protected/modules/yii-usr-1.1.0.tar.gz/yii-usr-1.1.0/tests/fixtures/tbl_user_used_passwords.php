<?php

return array(
	array(
		'user_id' => 1,
		'password' => '$2y$10$6q8D2lv/K73HNcDoEs01.ODNfLq7Wz/EzoAwtOJ4R8bUmCOujW4ky',
		'set_on' => '2011-11-11 12:34',
	),
);
