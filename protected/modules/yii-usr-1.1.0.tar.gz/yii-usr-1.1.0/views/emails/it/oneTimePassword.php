<p>
	Questo messaggio contiene una password a singolo utilizzo.<br>
        &Eacute; stata inviata da <?php echo CHtml::link(Yii::app()->name, $siteUrl); ?>. Se non avete eseguito voi la richiesta ignorate questa mail o contattate l'amministratore.
</p>

<p>Inserite il seguente codice nella pagina dai cui è stato richiesto:</p>
<h3><?php echo $code; ?></h3>
