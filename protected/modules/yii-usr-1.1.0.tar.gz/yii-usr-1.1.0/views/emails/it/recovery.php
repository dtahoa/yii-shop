<p>
	Questo messaggio contiene le istruzioni per effettuare un recupero password.<br>
        &Eacute; stata inviata da <?php echo CHtml::link(Yii::app()->name, $siteUrl); ?>. Se non avete eseguito voi la richiesta ignorate questa mail o contattate l'amministratore.
</p>

<p>Per impostare una nuova password apri il segunete link:</p>
<p>
<?php echo CHtml::link($actionUrl, $actionUrl); ?>
</p>
<p>
Se il link non si apre correttamente provate a copiarlo e incollarlo direttamente nel navigatore.
</p>
