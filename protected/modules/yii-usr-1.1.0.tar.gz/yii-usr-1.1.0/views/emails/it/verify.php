<p>
    Questo messaggio contiene istruzioni su come verificare questo indirizzo email.<br>
    &Eacute; stata inviata da <?php echo CHtml::link(Yii::app()->name, $siteUrl); ?>. Se non avete eseguito voi la richiesta ignorate questa mail o contattate l'amministratore.
</p>

<p>Per confermare questo indirizzo email, seguite il seguente link:</p>
<p>
<?php echo CHtml::link($actionUrl, $actionUrl); ?>
</p>
<p>
Se il link non si apre correttamente provate a copiarlo e incollarlo direttamente nel navigatore.
</p>
