<p>
	Ta wiadomość zawiera instrukcje, jak wykonać odzyskiwanie hasła. Została wysłana na polecenie użytkownika w serwisie <?php echo CHtml::link(Yii::app()->name, $siteUrl); ?>. Jeśli nie jesteś adresatem tej wiadomości, prosimy o jej zignorowanie lub kontakt z naszym administratorem.
</p>

<p>Aby ustawić nowe hasło, otwórz poniższy link:</p>
<p>
<?php echo CHtml::link($actionUrl, $actionUrl); ?>
</p>
<p>
Jeśli link nie otwiera się poprawnie, spróbuj skopiować go i wkleić w pasek adresu swojej przeglądarki.
</p>

