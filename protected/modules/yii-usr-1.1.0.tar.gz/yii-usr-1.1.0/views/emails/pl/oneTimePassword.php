<p>
	Ta wiadomość zawiera jednorazowe hasło. Została wysłana na polecenie użytkownika w serwisie <?php echo CHtml::link(Yii::app()->name, $siteUrl); ?>. Jeśli nie jesteś adresatem tej wiadomości, prosimy o jej zignorowanie lub kontakt z naszym administratorem.
</p>

<p>Wprowadź poniższy kod na stronie, która o niego poprosiła:</p>
<h3><?php echo $code; ?></h3>
