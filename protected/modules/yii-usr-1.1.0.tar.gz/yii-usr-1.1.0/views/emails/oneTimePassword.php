<p>
	This message contains a one time password. It was requested on the <?php echo CHtml::link(Yii::app()->name, $siteUrl); ?> website.
    If you did not perform this request, please ignore this email or contact our administrator.
</p>

<p>Enter this code on the page that requested it:</p>
<h3><?php echo $code; ?></h3>

